<?

//You can put script parts here and in the subdirs.

?>